# MongoDB attributes
mongodb_uri = "mongodb+srv://dbuser:Hello99@cluster0.npuqe2e.mongodb.net/?retryWrites=true&w=majority"
port = 8000
